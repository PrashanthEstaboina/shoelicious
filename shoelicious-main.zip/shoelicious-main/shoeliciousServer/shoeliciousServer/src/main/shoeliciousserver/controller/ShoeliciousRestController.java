package shoeliciousserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import shoeliciousserver.model.Shoe;
import shoeliciousserver.service.ShoeLiciousServerServiceImpl;

import java.util.List;

@Controller
public class ShoeliciousRestController {

    @Autowired
    ShoeLiciousServerServiceImpl shoeLiciousServerService;

    @PostMapping("/addProduct")
    public Shoe insertShoe(@RequestBody Shoe shoe ){
        System.out.println(shoe);
        System.out.println(shoe);
        //shoeLiciousServerService.insertShoe(shoe);
        return shoe;
    }

    @GetMapping("/showAllProduct")
    public ModelAndView showAllProduct(ModelAndView modelAndView){
        List<Shoe> shoes = shoeLiciousServerService.showAllProduct();
        modelAndView.addObject("shoes",shoes);
        modelAndView.setViewName("productList");
        return modelAndView ;
    }

    @GetMapping("/getProductById/{shoeId}")
    public ModelAndView getProductById(@PathVariable int shoeId,ModelAndView modelAndView){
        Shoe shoe = shoeLiciousServerService.getShoeById(shoeId);
        modelAndView.addObject(shoe);
        modelAndView.setViewName("displayProduct");
        return modelAndView;
    }

    @PostMapping("/productupdateform/updateProduct")
    public void updateProduct (@RequestBody Shoe shoe){
        Shoe shoeById = shoeLiciousServerService.getShoeById(shoe.getShoeId());
        shoeLiciousServerService.updateProduct(shoe);
    }

    @GetMapping("/productdeleteform/{id}")
    public String deleteProduct(@PathVariable int id){
      int i = shoeLiciousServerService.deleteProduct(id);
        return "redirect:/listofprodut";
    }

    @GetMapping("/addproduct")
    public String addProduct() {

        System.out.println("inside addproduct");

        return "addproduct";

    }


 @GetMapping("/listofprodut")
    public String list()
    {
        return "productList";

    }
@RequestMapping("/register")
    public String insert(Model model){
     model.addAttribute("shoe",new Shoe());
     return "insertForm";
    }



    @GetMapping("/buy")
    public String Product()
    {

        System.out.println("printing here");
        
        System.out.println("buy");
        System.out.println("buy1");
        System.out.println("print the buy details");

        return "buyPage";
    }


    @PostMapping("/insert")
    public Shoe insert(@ModelAttribute Shoe shoe )

    {
        System.out.println("cherry");
        shoeLiciousServerService.insertShoe(shoe);
        return shoe;
    }
    /*home page controller*/
    @GetMapping("/homepage")
    public String homePage(){
        System.out.println("Hi this is home page");
        System.out.println("this is home pagesssssssssss ");
        System.out.println("Hi this is home page && we return home page");
        return "homepage";
    }

    @GetMapping("/getProductById/backshowAllProduct")
    public String backshowAllProduct(){
        return "redirect:/showAllProduct";
    }

    @PostMapping("/addProducts")
    public Shoe insertShoes(@RequestBody Shoe shoe ){
        System.out.println(shoe);
        //shoeLiciousServerService.insertShoe(shoe);
        return shoe;
    }
}
