package shoeliciousserver.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shoeliciousserver.dao.ShoeliciousServerDaoImpl;
import shoeliciousserver.model.Shoe;

import java.util.List;

@Service
public class ShoeLiciousServerServiceImpl implements  ShoeLiciousServerService {

    @Autowired
    ShoeliciousServerDaoImpl shoeliciousServerDao;

    @Override
    public int insertShoe(Shoe shoe) {
        return shoeliciousServerDao.insertShoe(shoe);
    }

    @Override
    public List<Shoe> showAllProduct() {
        return shoeliciousServerDao.showAllProduct();
    }

    @Override
    public Shoe getShoeById(int id) {
        return shoeliciousServerDao.getShoeById(id);
    }

    @Override
    public int updateProduct(Shoe shoe) {
        return shoeliciousServerDao.updateProduct(shoe);
    }

    @Override
    public int deleteProduct(int id) {
        return shoeliciousServerDao.deleteProduct(id);
    }


}
