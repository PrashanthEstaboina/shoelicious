package shoeliciousserver.model;

public class Shoe {
    private int shoeId;
    private String shoeImage;
    private String shoeBrand;
    private String shoeName;
    private String shoeDesc;
    private String shoePrice;
    private String shoeCategory;



    public String getShoeImage() {
        return shoeImage;
    }

    public void setShoeImage(String shoeImage) {
        this.shoeImage = shoeImage;
    }

    public int getShoeId() {
        return shoeId;
    }

    public void setShoeId(int shoeId) {
        this.shoeId = shoeId;
    }

    public String getShoeName() {
        return shoeName;
    }

    public void setShoeName(String shoeName) {
        this.shoeName = shoeName;
    }

    public String getShoeDesc() {
        return shoeDesc;
    }

    public void setShoeDesc(String shoeDesc) {
        this.shoeDesc = shoeDesc;
    }

    public String getShoePrice() {
        return shoePrice;
    }

    public void setShoePrice(String shoePrice) {
        this.shoePrice = shoePrice;
    }

    public String getShoeCategory() {
        return shoeCategory;
    }

    public void setShoeCategory(String shoeCategory) {
        this.shoeCategory = shoeCategory;
    }
    public String getShoeBrand() {
        return shoeBrand;
    }

    public void setShoeBrand(String shoeBrand) {
        this.shoeBrand = shoeBrand;
    }

    @Override
    public String toString() {
        return "Shoe{" +
                "shoeId=" + shoeId +
                ", shoeImage='" + shoeImage + '\'' +
                ", shoeBrand='" + shoeBrand + '\'' +
                ", shoeName='" + shoeName + '\'' +
                ", shoeDesc='" + shoeDesc + '\'' +
                ", shoePrice='" + shoePrice + '\'' +
                ", shoeCategory='" + shoeCategory + '\'' +
                '}';
    }
}
