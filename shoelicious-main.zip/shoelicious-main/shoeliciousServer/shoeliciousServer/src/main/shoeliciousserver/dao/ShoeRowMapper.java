package shoeliciousserver.dao;

import org.springframework.jdbc.core.RowMapper;
import shoeliciousserver.model.Shoe;

import java.sql.ResultSet;
import java.sql.SQLException;


public class ShoeRowMapper implements RowMapper<Shoe> {

    @Override
    public Shoe mapRow(ResultSet rs, int rowNum) throws SQLException {

        Shoe shoe = new Shoe();
        shoe.setShoeId(rs.getInt(1));
        shoe.setShoeImage(rs.getString(2));
        shoe.setShoeBrand(rs.getString(3));
        shoe.setShoeName(rs.getString(4));
        shoe.setShoeDesc(rs.getString(5));
        shoe.setShoePrice(rs.getString(6));
        shoe.setShoeCategory(rs.getString(7));
        return shoe;
    }
}
