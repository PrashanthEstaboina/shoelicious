package shoeliciousserver.dao;

import shoeliciousserver.model.Shoe;

import java.util.List;

public interface ShoeliciousServerDao {

    public int  insertShoe(Shoe shoe);

    public List<Shoe> showAllProduct();

    public Shoe getShoeById( int id );

    public int updateProduct( Shoe shoe );

    public int deleteProduct( int id );

}
