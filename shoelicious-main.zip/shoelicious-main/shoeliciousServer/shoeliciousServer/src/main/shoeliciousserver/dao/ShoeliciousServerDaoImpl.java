package shoeliciousserver.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import shoeliciousserver.model.Shoe;

import java.util.List;

@Repository
public class ShoeliciousServerDaoImpl implements ShoeliciousServerDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public int insertShoe(Shoe shoe) {
        String query= "insert into shoe(shoeimage,shoebrand, shoename , shoedescription , shoeprice , shoecategory) value(?,?,?,?,?,?)";
        return getJdbcTemplate().update(query, shoe.getShoeImage(), shoe.getShoeBrand(),shoe.getShoeName(),shoe.getShoeDesc(),shoe.getShoePrice(),shoe.getShoeCategory());
    }

    @Override
    public List<Shoe> showAllProduct() {
        String query= "Select * from shoe";
        List<Shoe> shoes = getJdbcTemplate().query(query, new ShoeRowMapper());
        return shoes;
    }
    @Override
    public Shoe getShoeById( int id ) {
        String query= "Select * from shoe where shoeID=?";
        Shoe shoe = getJdbcTemplate().queryForObject(query, new ShoeRowMapper(), id);
        return shoe;
    }

    @Override
    public int updateProduct(Shoe shoe) {

        String query = "update shoe set  shoeimage=?, shoebrand=?,shoename=?,shoedescription=?,shoeprice=?,shoecategory=? where shoeID =?";
        return getJdbcTemplate().update(query, shoe.getShoeImage(),shoe.getShoeBrand(),shoe.getShoeName(),shoe.getShoeDesc(),shoe.getShoePrice(),shoe.getShoeCategory() , shoe.getShoeId());
    }

    @Override
    public int deleteProduct(int id) {
        String query= "delete from shoe where shoeID=?";

        return jdbcTemplate.update(query,id);
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
